---
name: "notion-note-taker"
description: "Transforme une transcription brute de cours (audio retranscrit) en fiche de notes structurée, complète et prête pour Notion : soit un fichier Markdown à importer (callouts natifs aside, propriétés de page, tableaux, Mermaid, LaTeX), soit un ajout direct à une page Notion existante dont l'utilisateur donne le lien (notes datées, travaux créés dans la base Travail si disponible ou to-do list intégrée). Optimisé pour les templates Notion du Kit DGI (notamment DIC1 et DIC2 Informatique ESP), tout en restant pleinement compatible avec tout autre espace Notion. Si l'utilisateur n'utilise pas Notion ou préfère des notes markdown locales dans Obsidian, utiliser le skill obs-note-taker à la place. Toutes matières (informatique, mathématiques, réseaux, télécoms, bases de données, etc.)."
---

# Notion-Note-Taker — Fiche de cours pour Notion

Transforme une transcription brute de cours en notes propres et complètes que Notion accepte sans retouche manuelle : callouts natifs, propriétés de page, tableaux, diagrammes Mermaid et formules.

Deux modes de sortie, à choisir dès le début :

| Mode | Quand | Sortie |
| --- | --- | --- |
| **A. Nouvelle fiche** | Pas de lien de page, ou demande de fichier à importer | Fichier `.md` au format d'export Notion (`<aside>`) |
| **B. Ajout à une page existante** | L'utilisateur donne un lien Notion (« ajoute les notes du jour sur cette page ») | Écriture directe dans la page via les outils Notion (callouts `<callout>`), voir étape 9 |

Le lien d'une page Notion vaut demande explicite d'écrire dans Notion.

---

## Étape 0 — Une seule passe, toujours

Traiter **toute** la transcription d'un bloc, quelle que soit sa longueur.

- ❌ Ne jamais découper en parties ni demander « suite ».
- ❌ Ne jamais résumer, condenser ou sauter un passage de **contenu de cours**.
- ✅ Garder définitions, exemples, remarques sur les pièges, consignes d'examen ou de TP.
- ✅ En cas de doute sur un passage de cours → le garder.

## Étape 1 — Nettoyer la transcription

| À supprimer | À conserver absolument |
| --- | --- |
| Salutations, bavardages d'ouverture/fermeture | Toutes les définitions |
| Administratif sans lien avec le contenu | Formules et démonstrations |
| Problèmes techniques (« on vous entend pas ») | Tous les exemples, même rapides |
| Répétitions dues à l'hésitation | Consignes d'examen ou de TP |
| **Échanges avec les élèves** : questions-réponses, réponses fausses ou hésitantes, appels de présence | Remarques sur les pièges et erreurs fréquentes |
| Fautes de transcription évidentes (corriger sans le dire) | Les corrections et conclusions finales énoncées par l'enseignant |

Règles :

- **Les interventions des élèves ne sont pas du cours**, y compris celles de l'utilisateur (lignes « You » / « Moi »). Ne garder que ce que l'enseignant établit. Si l'utilisateur dit d'ignorer ses propres interventions, les ignorer entièrement.
- **Ne jamais raconter l'échange** : pas de « un étudiant a répondu… », « le prof n'était pas satisfait », « le prof hésite entre trois et quatre ». Ne garder que le fait de cours qui en ressort.
- Ordonner les sections selon la **logique du cours**, pas l'ordre chronologique si la transcription est décousue. Une transcription audio contient des mots mal reconnus (noms de variables, de classes, de commandes) : les rétablir d'après le contexte technique.

## Étape 2 — Structure de la fiche

### 2.1 En-tête (mode A uniquement)

Notion lit les lignes `Clé: valeur` placées juste sous le titre comme **propriétés de la page** (page de la base « Chapitres »). Gabarit exact :

```markdown
# [Titre du chapitre]

Fait: No
Matière: [nom de la matière]
N°: [numéro du chapitre]

# [Titre du chapitre développé]

---
```

- `Fait: No` par défaut. `Matière` : nom détecté ou donné par l'utilisateur ; s'il fournit le lien de la page de la matière, écrire `Nom (https://…)` pour que la relation se fasse à l'import. `N°` : numéro cité, sinon ligne vide (ne pas inventer).
- Pas de bloc « Nom / Prénom / Classe ».
- Si la page n'est **pas** dans une base, supprimer les trois lignes de propriétés et garder le titre seul.
- En **mode B**, ne jamais écrire d'en-tête : titre et propriétés existent déjà.

### 2.2 Titres

- Sections : `## Titre` (numéroter `## 1. Titre` seulement en mode A ; en mode B, suivre la page existante), sous-sections : `### Titre`.
- Notion gère 3 niveaux. `####` est réservé aux titres de callouts (mode A), **sauf** en mode B si la page existante utilise déjà des `####` comme intitulés : on peut alors en mettre pour un petit intitulé de sous-bloc (par exemple « Démarche à suivre : »), hors callout.
- Séparer les grandes sections par `---`.
- Pas d'emoji dans les titres de sections.

## Étape 3 — Callouts

### 3.1 Format mode A (fichier `.md`, balise `<aside>`)

Lignes vides obligatoires :

```markdown
<aside>
⚠️

#### **Titre du callout**

Contenu du callout.

</aside>
```

- L'emoji est seul sur sa ligne, juste après `<aside>`. Titre en `####` gras, ligne vide, contenu, ligne vide avant `</aside>`.
- Jamais `> [!info]` (Obsidian) ni `> ⚠️ **Titre**` (citation simple).

### 3.2 Format mode B (outils Notion, balise `<callout>`)

```markdown
<callout icon="⚠️" color="orange_bg">
<b>Titre du callout</b>

Contenu du callout.
</callout>
```

- Pas de ligne vide collée à la balise ouvrante ni à la balise fermante (elle devient une ligne parasite). Le contenu suit le titre après une ligne vide.
- Couleurs par emoji : 💡 `yellow_bg`, ℹ️ `blue_bg`, ⚠️ `orange_bg`, ✅ `green_bg`, ❌ `red_bg`, ❓ `purple_bg`, 📝 `gray_bg`, 📌 `blue_bg`, ☑️ `gray_bg`.
- Avant d'écrire, lire `notion://docs/notion-flavored-markdown-spec` avec `notion-fetch` : n'écrire aucune balise HTML autre que celles du format (pas de `<details>` : utiliser `<toggle>`), formules display avec `$$` seuls sur leur ligne.

### 3.3 Règles communes

- **Callout court = une seule phrase en gras, sans titre séparé.** Exemple : `<b>Surdéfinition</b> et <b>redéfinition</b> sont deux notions différentes.` Un titre n'est justifié que si le callout contient plusieurs lignes ou une liste.
- Aucun titre ni phrase ne mentionne l'enseignant (voir étape 7).
- Listes, code inline, gras et formules fonctionnent dans un callout. Éviter tableaux, blocs de code longs, diagrammes et callouts imbriqués : les placer juste après.

Emojis imposés (n'utiliser que ces neuf) :

| Usage | Emoji |
| --- | --- |
| Définition, astuce, bonne pratique | 💡 |
| Information, rappel, convention | ℹ️ |
| Piège, erreur fréquente, vigilance | ⚠️ |
| Résultat, propriété démontrée, règle validée | ✅ |
| Contre-exemple, ce qui ne marche pas | ❌ |
| Question ouverte, exercice posé en cours | ❓ |
| Exemple détaillé | 📝 |
| Récapitulatif de séance, de section ou de chapitre | 📌 |
| Travail à faire | ☑️ |

### 3.4 Récap daté 📌

Terminer chaque ajout de séance par un récap, avec **la date du jour dans le titre** pour distinguer les séances sans remonter dans la page :

```markdown
<callout icon="📌" color="blue_bg">
<b>À retenir</b> <date start="2026-10-27" />

- Point clé 1
- Point clé 2
</callout>
```

(En mode A, écrire la date en clair : `#### **À retenir — 27/10/2026**`.)

## Étape 4 — Formules

- Inline : `$formule$` ; centrée : `$$formule$$` (en mode B, `$$` seuls sur leur ligne).
- Vérifier les accolades. Systèmes : `\begin{cases}…\end{cases}`.
- LaTeX seulement pour les vrais objets mathématiques ou scientifiques. Une valeur simple s'écrit en texte : `180°C`, `10 %`, `5 V`.
- Éviter `$` pour autre chose qu'une formule. Aucune formule dans un bloc de code, sauf demande.

## Étape 5 — Diagrammes Mermaid

Bloc de code de langage `mermaid`.

- **Pas** de bloc de configuration en tête : commencer par `flowchart TD`, `timeline` ou `sequenceDiagram`.
- Choix : hiérarchie, processus, algorithme, architecture → `flowchart TD` ; chronologie → `timeline` ; échanges, appels → `sequenceDiagram`.
- Palette `classDef` en fin de diagramme (concepts principaux en bleu, exemples en vert, avertissements en rose) :

```
classDef bleu fill:#b3cde3,stroke:#5b7c9e,color:#2c3e50
classDef vert fill:#cce6d4,stroke:#7fa87f,color:#2c3e50
classDef beige fill:#f4d4b3,stroke:#c29a6b,color:#2c3e50
classDef lavande fill:#d9cce6,stroke:#9578b3,color:#2c3e50
classDef rose fill:#f4cccc,stroke:#c47a7a,color:#2c3e50
classDef glacier fill:#cce5f2,stroke:#7a9eb3,color:#2c3e50
classDef peche fill:#fde2c4,stroke:#c9a87b,color:#2c3e50
classDef mauve fill:#e1d5e7,stroke:#a58db3,color:#2c3e50
```

Règles anti-bug :

- ❌ Pas de `\n`, de parenthèses `()`, de `×` `±` `≤` `≥` dans les labels (écrire `x`, `+-`, `<=`, `>=`) ; pas d'accents dans les nœuds si le rendu pose problème.
- ✅ Identifiants de nœuds uniques, ligne vide avant et après le bloc.

## Étape 6 — Tableaux et code

**Tableaux** : syntaxe standard, une ligne `| --- |`, une seule ligne de texte par cellule, pas de liste ni de bloc dans une cellule. Un `|` affiché s'écrit `\|`.

**Code** : toujours un bloc clôturé avec le langage, ligne vide avant et après, indentation cohérente (4 espaces Python/Java/C, 2 espaces JSON/YAML), jamais de tabulations. Un bloc de code ne se met pas dans un callout.

## Étape 7 — Fiche impersonnelle et honnêteté sur la source

### 7.1 Aucune mention de l'enseignant

La fiche est un document de révision personnel, pas un compte rendu de séance. Ne jamais écrire « le prof dit / insiste / surligne / demande / attend / hésite », « exemple du prof », « version du prof », « exercice laissé par le prof », « suis la démarche du prof pour l'examen ». Écrire le contenu directement : « Exemple : … », « Exercice : … », « Raison : … ».

### 7.2 Ce qui était à l'écran : ne pas le reconstituer

Quand l'enseignant décrit à l'oral un code, un schéma ou une diapo affichés :

- Si l'utilisateur a fourni le code ou la capture dans la conversation → l'utiliser tel quel (ne pas le réécrire).
- Sinon → **ne pas inventer** de code, de tableau ou de hiérarchie à partir de la description orale. Insérer un emplacement court :

```markdown
<callout icon="⚠️" color="orange_bg">
<b>À compléter : capture de la diapo (hiérarchie des classes A, B, C, D, E)</b>
</callout>
```

  puis demander dans la réponse la capture ou le code correspondant. Seule exception : un squelette minimal indispensable à la compréhension, marqué ⚠️ « À vérifier avec la diapo ».

### 7.3 Ajouts hors cours

Autorisés seulement s'ils évitent une erreur et s'ils sont **techniquement exacts** (en cas de doute sur la formulation précise, ne pas écrire l'ajout). Les placer dans un callout 💡 intitulé **« D'après mes recherches… »**, sans mention de l'enseignant ni consigne d'examen.

### 7.4 Contradiction ou ambiguïté

Rapporter la règle telle qu'énoncée, puis signaler l'ambiguïté dans un callout ⚠️ (sans nommer l'enseignant). Ne jamais présenter un ajout personnel comme une affirmation du cours.

## Étape 8 — Travail à faire : base Notion dédiée ou to-do list intégrée

Selon l'organisation de l'espace Notion de l'utilisateur :

### 8.1 Cas 1 : Avec le template du Kit DGI (ou base « Travail » présente)

Si l'utilisateur dispose du template Notion du Kit DGI (notamment les templates pour DIC1 et DIC2 Informatique) ou d'une base de devoirs existante :
1. **Trouver la base** : La base se trouve sous la même page de niveau que la base « Chapitres » (ex. page « DIC2 INFO »). Partir du chemin `ancestor-path` de la page du chapitre, ou chercher « Travail (cours · TD · TP) » avec `notion-search`. Faire un `notion-fetch` de la base pour confirmer le schéma avant de créer.
2. **Propriétés de la sous-page de travail** :
   | Propriété | Valeur |
   | --- | --- |
   | `Titre` | Nom court du concept ou de l'exercice (ex. « Redéfinition »), pas une phrase |
   | `Chapitre` | Relation : URL de la page du chapitre en cours |
   | `Matière` | Relation : reprendre la valeur `Matière` de la page du chapitre |
   | `Statut` | `À faire`, `En cours` ou `Terminé` |
   | `Date` | Si le travail est résolu pendant la séance → date du jour. Sinon → échéance donnée par l'utilisateur ou l'enseignant ; à défaut, **date du jour + 7 jours** (le mentionner dans la réponse) |
   | `Type` | `Cours`, `TD`, `TP` ou `Fiche de révision` si c'est clair ; sinon laisser vide |
   | `Priorité` | Laisser vide sauf indication de l'utilisateur |
3. **Contenu de la page de travail** :
   - Consigne dans un callout `💡 blue_bg` titré **EXERCICE**.
   - Si la solution est connue : titre `<i><b><u>SOLUTION</u></b></i>`, explication en une ou deux phrases, puis bloc de code. Statut `Terminé`.
   - Si le travail reste à faire : consigne seule. Statut `À faire`.
4. **Tag dans la page du cours** : Créer les pages de travail **avant** d'écrire la page du cours (il faut leurs URLs), puis insérer :
   ```markdown
   <callout icon="☑️" color="gray_bg">
   <b>Travail à faire</b>

   <mention url="https://app.notion.com/p/…" />
   </callout>
   ```

### 8.2 Cas 2 : Sans base dédiée (Fallback universel)

Si la base « Travail » n'est pas trouvée (ex. étudiant d'une autre filière, espace personnel non basé sur le template du kit, ou mode fichier A sans accès direct API) :
- Ne jamais bloquer l'exécution ni afficher d'erreur.
- Insérer directement les travaux à faire dans la page de cours dans un callout propre avec des cases à cocher :
  - **En mode B (écriture directe Notion)** :
    ```markdown
    <callout icon="☑️" color="gray_bg">
    <b>Travail à faire</b>

    - [ ] **[Type : Exercice / TD / TP]** Nom de l'exercice — Consigne synthétique (Échéance suggérée : J+7)
    </callout>
    ```
  - **En mode A (fichier Markdown exporté)** :
    ```markdown
    <aside>
    ☑️
    **Travail à faire**

    - [ ] **[Type : Exercice / TD / TP]** Nom de l'exercice — Consigne synthétique (Échéance suggérée : J+7)
    </aside>
    ```

> 💡 **Rappel** : Si l'utilisateur n'utilise pas Notion et préfère une prise de notes locale en Markdown pour Obsidian, orienter vers le skill **`obs-note-taker`**.

## Étape 9 — Livraison

### Mode A (fichier)

1. Écrire `/mnt/user-data/outputs/chapitre-[n]-[sujet].md` (minuscules, tirets, sans accents) puis `present_files`.
2. Réponse brève : ce qui a été ajouté hors cours, ce qui manque (captures), et rappeler que le bloc Mermaid doit avoir le langage « Mermaid » sélectionné dans Notion s'il s'affiche comme du code.
3. N'écrire dans Notion que sur demande explicite ; dans ce cas, passer au mode B.

### Mode B (page existante)

1. Charger les outils Notion avec `tool_search`, puis `notion-fetch` de la page : lire le contenu existant, les propriétés, le chemin et le style en place (niveaux de titres, présence de `####`, couleurs).
2. Créer les pages de travail dans la base (étape 8) si la séance en contient.
3. Insérer **à la fin** de la page avec `notion-update-page`, commande `insert_content`, position `end` : ne jamais modifier ni supprimer le contenu existant, les propriétés ni le titre. Structure de l'ajout :
   1. `---`
   2. la date du jour sur son propre paragraphe : `<date start="AAAA-MM-JJ" />`
   3. les sections de la séance (étapes 2 à 7)
   4. le callout ☑️ « Travail à faire » avec les mentions (si besoin)
   5. le récap 📌 daté (étape 3.4)
4. Ne pas relire la page pour vérifier sauf avertissement dans le résultat ; rapporter les avertissements.
5. Réponse brève : ce qui a été ajouté, les travaux créés (avec lien), les captures ou codes à fournir pour les emplacements « À compléter », les ajouts hors cours. Terminer par une seule prochaine étape.

## Si l'entrée est une fiche Obsidian existante

Convertir sans perdre de contenu :

| Obsidian | Notion |
| --- | --- |
| `> [!info] Titre` + contenu | callout (`<aside>` ou `<callout>`) + emoji de la charte |
| `[[lien]]` / `![[image]]` | texte simple (ou lien Markdown si l'URL est connue) |
| `==surligné==` | `**gras**` |
| Frontmatter YAML | lignes de propriétés `Clé: valeur` (mode A) |
| Bloc `[!info]` Nom/Prénom/Classe | supprimé |
| Mermaid avec bloc `config` | Mermaid sans bloc `config` |

---

## Checklist finale

- [ ] Transcription traitée en une seule passe ; échanges avec les élèves et interventions de l'utilisateur écartés
- [ ] Aucune mention de l'enseignant dans les titres ni le texte
- [ ] Mode choisi : A (fichier, avec en-tête) ou B (ajout à la fin, sans en-tête)
- [ ] Mode B : page lue avant d'écrire, contenu existant intact, `---` puis date du jour en tête de l'ajout
- [ ] Callouts au bon format (`<aside>` en A, `<callout>` en B), neuf emojis seulement, callouts courts sans titre
- [ ] Rien reconstitué à partir de l'oral : code ou schéma fourni utilisé tel quel, sinon emplacement « À compléter » + demande dans la réponse
- [ ] Ajouts hors cours exacts, dans « D'après mes recherches… »
- [ ] Travaux créés dans la base Travail si disponible (avec tag), ou to-do list intégrée directement dans la page de notes
- [ ] Récap 📌 en fin de séance avec la date du jour dans le titre
- [ ] Formules LaTeX seulement pour les vraies formules ; Mermaid sans `config`, avec `classDef` ; tableaux simples ; code avec langage hors callouts
- [ ] Fiche en français (termes techniques anglais conservés)
- [ ] Mode A : fichier `.md` livré via `present_files`

---

## Exemple de sortie : mode A (structure minimale)

````markdown
# Multiplexage

Fait: No
Matière: Bases des Télécommunications
N°: 3

# Le multiplexage

---

## 1. Introduction

Le multiplexage permet de faire transiter plusieurs signaux sur un même support physique.

<aside>
💡

#### **Définition : multiplexage**

Technique qui consiste à combiner plusieurs flux d'information sur un seul canal de transmission.

</aside>

<aside>
📌

#### **À retenir — 27/10/2026**

- Le multiplexage partage un canal entre plusieurs flux.

</aside>
````

## Exemple de sortie : mode B (ajout à une page existante)

````markdown
---

<date start="2026-10-27" />

## Le masquage

<callout icon="💡" color="yellow_bg">
<b>Masquage</b> : un élément de programme devient inaccessible à cause d'un autre élément de même nom.
</callout>

<callout icon="☑️" color="gray_bg">
<b>Travail à faire</b>

<mention url="https://app.notion.com/p/…" />
</callout>

<callout icon="📌" color="blue_bg">
<b>À retenir</b> <date start="2026-10-27" />

- Un élément masqué reste atteignable par un préfixe (ex. `super.retirer(...)`).
</callout>
````
