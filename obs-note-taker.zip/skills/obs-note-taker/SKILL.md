---
name: obs-note-taker
description: "Transforme une transcription brute de cours (audio retranscrit) en fiche de notes structurée, complète et prête pour Obsidian. Utilise ce skill dès que l'utilisateur fournit une transcription de cours, un enregistrement retranscrit, ou demande à \"faire une fiche\", \"structurer mes notes\", \"mettre en forme ce cours\", \"générer une fiche Obsidian\" ou toute formulation similaire. Déclenche aussi si l'utilisateur colle du texte brut qui ressemble à un cours ou à une prise de notes désorganisée. Ce skill s'applique à toutes les matières (mathématiques, informatique, télécommunications, électronique, réseaux, bases de données, etc.)."
---

# Obs-Note-Taker — Fiche de cours Obsidian

Transforme une transcription brute de cours en fiche Obsidian propre, structurée et complète.  
La fiche finale doit être exportable directement dans Obsidian sans aucune retouche.

---

## Étape 0 — Règle de traitement : une seule passe, toujours

**Quelle que soit la longueur de la transcription**, traiter l'intégralité en une seule passe et produire la fiche complète d'un bloc.

- ❌ Ne jamais découper en parties, ne jamais demander à l'utilisateur de dire "suite".
- ❌ Ne jamais résumer, condenser ou sauter des passages pour des raisons de longueur.
- ✅ Tous les détails sont importants — définitions, exemples, remarques du prof, consignes d'examen : tout doit figurer dans la fiche.
- ✅ Produire directement un **artefactMarkdown complet**, prêt à coller dans Obsidian sans aucune retouche.

---

## Étape 1 — Nettoyer la transcription

Avant de structurer, passe mentalement par ce filtre :

| À supprimer | À conserver absolument |
|---|---|
| Salutations, bavardages d'ouverture/fermeture | Toutes les définitions |
| Discussions administratives sans lien avec le contenu | Toutes les formules et démonstrations |
| Problèmes techniques ("on entend pas", "coupez le micro") | Tous les exemples, même rapides |
| Répétitions verbatim dues à l'hésitation | Les consignes d'examen ou de TP |
| Fautes de transcription évidentes (corriger silencieusement) | Les remarques du prof sur les pièges courants |

> **Règle d'or** : En cas de doute sur si quelque chose doit rester → le garder.

---

## Étape 2 — Construire la structure de la fiche

### En-tête obligatoire

```markdown
> [!info] Informations
>
> **Nom** : [à compléter]
> **Prénom** : [à compléter]
> **Classe** : [à compléter]
> **Semestre** : [à compléter]
> **Cours** : [nom de la matière détecté dans la transcription]
```

### Titre principal

```markdown
# 📘 [Matière] — [Sujet principal] (Séance X)
```

Si le numéro de séance n'est pas mentionné, omettre la partie `(Séance X)`.

### Sous-sections

Utiliser des titres numérotés :
```markdown
## 1. [Titre de la section]
### 1.1 [Sous-section si nécessaire]
```

Les sections doivent suivre l'ordre logique du cours, pas l'ordre chronologique de la transcription si celui-ci est décousu.

---

## Étape 3 — Callouts Obsidian

Utiliser **uniquement** ces callouts (jamais d'autres) :

| Callout | Usage |
|---|---|
| `> [!info]` | Informations contextuelles, rappels |
| `> [!tip]` | Astuces, bonnes pratiques |
| `> [!warning]` | Pièges, erreurs fréquentes, points de vigilance |
| `> [!success]` | Résultats, conclusions, propriétés démontrées |
| `> [!fail]` | Contre-exemples, ce qui ne fonctionne pas |
| `> [!question]` | Questions ouvertes, exercices posés en cours |
| `> [!summary]` | Récapitulatifs de section |
| `> [!example]` | Exemples détaillés |
| `> [!todo]` | Travail à faire, exercices à compléter |

Format exact — **le titre et le contenu doivent toujours être sur des lignes séparées** :

```markdown
> [!warning] Titre du callout
>
> Contenu du callout.
```

> ⚠️ **Règle absolue** : toujours insérer une ligne `>` vide entre le titre et le contenu du callout. Ne jamais mettre le contenu sur la même ligne que `[!type]`. Sans ce retour à la ligne, Obsidian ne distingue pas le titre du contenu.

---

## Étape 4 — Formules mathématiques

- Inline : `$formule$` — ex : `$i = \frac{dq}{dt}$`
- Centrée : `$$formule$$`
- Toujours vérifier que les accolades LaTeX sont correctement fermées.
- Pour les systèmes d'équations, utiliser `\begin{cases}...\end{cases}`.

---

## Étape 5 — Diagrammes Mermaid

### Configuration obligatoire en en-tête de chaque diagramme

````markdown
```mermaid
---
config:
  theme: base
  maxTextSize: 900
  flowchart:
    useMaxWidth: true
    htmlLabels: true
  themeVariables:
    fontSize: '12px'
---
```
````

### Choix du type de diagramme

| Contexte | Type Mermaid à utiliser |
|---|---|
| Hiérarchie, processus, algorithme, architecture | `flowchart TD` |
| Chronologie, évolution historique, générations technologiques | `timeline` |
| Échanges entre composants, protocoles, appels de fonctions | `sequenceDiagram` |

### Palette de couleurs `classDef` (obligatoire)

```
classDef bleu fill:#b3cde3,stroke:#5b7c9e,color:#2c3e50
classDef vert fill:#cce6d4,stroke:#7fa87f,color:#2c3e50
classDef beige fill:#f4d4b3,stroke:#c29a6b,color:#2c3e50
classDef lavande fill:#d9cce6,stroke:#9578b3,color:#2c3e50
classDef rose fill:#f4cccc,stroke:#c47a7a,color:#2c3e50
classDef glacier fill:#cce5f2,stroke:#7a9eb3,color:#2c3e50
classDef peche fill:#fde2c4,stroke:#c9a87b,color:#2c3e50
classDef mauve fill:#e1d5e7,stroke:#a58db3,color:#2c3e50
```

Assigner les classes aux nœuds selon leur rôle sémantique (ex : concepts principaux en bleu, exemples en vert, avertissements en rose).

### Règles anti-bug Mermaid

- ❌ Pas de `\n` dans les labels → remplacer par un espace
- ❌ Pas de parenthèses `()` dans les labels de nœuds → reformuler
- ❌ Pas de `×`, `±`, `≤`, `≥` dans les nœuds → utiliser `x`, `+-`, `<=`, `>=`
- ❌ Pas de liste Markdown (`-` ou `1.`) directement collée à un bloc mermaid → laisser une ligne vide avant et après
- ✅ Toujours tester mentalement que chaque nœud a un identifiant unique

---

## Règle d'indentation des blocs de code

Pour tout bloc de code (` ```langage ... ``` `) inséré dans la fiche :

- ✅ Le contenu du bloc doit être **indenté de manière cohérente** avec le langage (ex : Python/C → 4 espaces, JSON/YAML → 2 espaces).
- ✅ Si le code apparaît à l'intérieur d'une liste ou d'un callout, s'assurer que l'indentation du bloc correspond au niveau d'imbrication Markdown.
- ❌ Ne jamais mélanger tabulations et espaces dans un même bloc.
- ❌ Ne jamais coller un bloc de code directement contre une ligne de texte sans ligne vide séparatrice.

---

## Étape 6 — Tableaux

Pour toute donnée structurée (comparaisons, caractéristiques, paramètres) :

```markdown
| Colonne 1 | Colonne 2 | Colonne 3 |
|-----------|-----------|-----------|
| valeur    | valeur    | valeur    |
```

---



## Checklist finale avant livraison

Avant de produire la fiche, vérifier mentalement :

- [ ] Fiche produite **en une seule passe**, sans découpage ni omission
- [ ] Sortie sous forme de **document Markdown complet** prêt à coller dans Obsidian
- [ ] En-tête `[!info]` présent
- [ ] Titre `# 📘` correct
- [ ] Toutes les définitions du cours présentes
- [ ] Toutes les formules en LaTeX correct
- [ ] Diagrammes Mermaid avec config + classDef
- [ ] Callouts : **ligne vide `>` entre le titre et le contenu** dans chaque callout
- [ ] Callouts uniquement parmi la liste autorisée
- [ ] Blocs de code correctement **indentés** selon le langage, avec ligne vide avant/après
- [ ] Aucun `\n` dans les nœuds Mermaid
- [ ] Ligne vide avant/après chaque bloc mermaid
- [ ] Fiche en **français** (même si la transcription contient des termes techniques en anglais — les conserver tels quels)
- [ ] Aucune information omise

---

## Exemple de sortie attendue (structure minimale)

```markdown
> [!info] Informations
>
> **Nom** : [à compléter]
> **Prénom** : [à compléter]
> **Classe** : DIC1
> **Semestre** : S2
> **Cours** : Télécommunications

# 📘 Télécommunications — Multiplexage (Séance 3)

## 1. Introduction au multiplexage

Le multiplexage permet de faire transiter plusieurs signaux sur un même support physique.

> [!info] Définition
>
> Le **multiplexage** est une technique qui consiste à combiner plusieurs flux d'information sur un seul canal de transmission.

## 2. Types de multiplexage

| Type | Principe | Usage |
|------|----------|-------|
| FDM  | Division en fréquences | Radio, TV analogique |
| TDM  | Division temporelle | Téléphonie numérique |
| CDM  | Division par codes | 3G/4G |

[diagramme Mermaid flowchart TD ici]

## 3. Formules clés

Capacité de Shannon : $C = B \log_2(1 + \frac{S}{N})$
```