---
name: notion-banner-creator
description: Crée des bannières de couverture Notion personnalisées, panoramiques et adaptées au recadrage de Notion, avec une composition lisible et un ratio cible de 7:1.
---

# Notion Banner Creator

## Objectif
Créer une bannière de couverture pour une page Notion à partir du sujet fourni par l’utilisateur. Le résultat doit être esthétique, immédiatement reconnaissable, lisible une fois affiché dans Notion et conçu pour un format extrêmement panoramique.

## Déclencheurs
Utiliser ce skill lorsque l’utilisateur demande de créer, générer, refaire ou adapter une bannière/couverture Notion, notamment pour un cours, une matière, un projet ou une page de notes.

## Procédure
1. **Identifier le sujet** et les éventuelles préférences déjà données dans la conversation : palette, style, texte, éléments visuels et ratio.
2. Si le sujet est clair, ne pas poser de question inutile : choisir des détails visuels cohérents avec le thème.
3. **Créer une image panoramique au ratio cible 7:1.** Viser par exemple 2800 × 400 px ou 2100 × 300 px. Si l’outil d’image ne permet pas de générer exactement ce ratio, générer la composition la plus panoramique possible, puis recadrer/redimensionner l’image finale à 7:1 sans étirer les éléments.
4. Composer l’image pour une couverture Notion :
   - garder le titre principal près du centre et suffisamment grand ;
   - placer les éléments secondaires vers les côtés ;
   - si une icône de page est fournie ou créée avec la bannière, réserver une zone de sécurité vide en bas à gauche : dans Notion, l’icône se superpose généralement à cette partie de la couverture ; ne placer aucun nœud, libellé, titre ou détail important sous cette zone ;
   - déplacer les éléments visuels de gauche vers la partie haute gauche ou vers la droite, et vérifier la bannière avec l’icône superposée si une capture ou une position réelle est disponible ;
   - éviter les détails importants tout en haut ou tout en bas, car Notion peut recadrer l’image selon l’affichage ;
   - garder des marges de sécurité ;
   - éviter une grande zone vide inutile ;
   - privilégier une composition horizontale, simple et immédiatement lisible.
5. Ajouter seulement du texte utile : titre, éventuellement un sous-titre court et quelques termes visuels pertinents. Vérifier les accents et l’orthographe française. Si le titre est long, le composer sur une seule ligne compacte ou réduire le texte avant le recadrage 7:1 ; ne jamais laisser un titre ou un sous-titre coupé par le recadrage.
6. Utiliser une direction artistique cohérente avec le sujet. Pour une matière informatique, par exemple : illustration vectorielle douce, bleu/indigo, éléments de code, schémas et objets d’étude. Ne pas réutiliser automatiquement cette palette si l’utilisateur demande autre chose.
7. **Exporter une version finale réellement au ratio 7:1** et vérifier les dimensions de l’image avant de fournir le lien. Ne jamais annoncer « ratio exact » sans avoir vérifié le fichier.
8. Si une icône est demandée avec la bannière, vérifier visuellement le couple bannière + icône : l’icône doit rester reconnaissable en très petit format et ne doit masquer aucun texte ni élément essentiel. Fournir les fichiers finaux et leurs liens vérifiés. Garder la réponse courte ; donner une instruction Notion uniquement si elle est utile.

## Principes de conception
- Priorité à la lisibilité dans une bande très basse.
- Titre principal visible même en petit aperçu.
- Contraste suffisant entre texte et fond.
- Zone de chevauchement Notion anticipée : garder la partie basse gauche volontairement calme lorsqu’une icône de page est utilisée, avec un contraste suffisant entre l’icône et la bannière.
- Style soigné, pas trop chargé, sans logos ou marques ajoutés sans demande.
- Ne pas ajouter de texte, d’icônes ou de décor sans rapport avec le sujet.
- Respecter les préférences explicites de l’utilisateur et les éléments déjà validés dans le fil.

## Gestion des demandes
- « Ratio 7:1 » : livrer une image dont largeur ÷ hauteur = 7, vérifié après export.
- « La largeur est parfaite mais la longueur/hauteur ne tient pas » : conserver la direction artistique, réduire la hauteur en recomposant ou en recadrant intelligemment, et ne pas simplement étirer l’image.
- « L’icône chevauche la bannière » : réserver la zone basse gauche à l’icône, déplacer les schémas vers le haut ou la droite, puis recadrer et vérifier le résultat avec l’icône superposée.
- « L’icône doit être visible dans la liste des pages » : produire un symbole simple, à silhouette forte, avec peu de détails, un contour contrasté et aucun texte fin.
- « Refais-la » : garder les choix appréciés et modifier uniquement ce qui a été demandé.
- Sujet suffisamment clair : créer directement sans demander confirmation.

## Livrable
Une image PNG finale, au ratio demandé et prête à importer comme couverture Notion, avec un lien de téléchargement vérifié.
