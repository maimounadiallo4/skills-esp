---
name: dgi-academic-formatter
description: >
  Applique les normes officielles de rédaction académique du Département Génie Informatique (DGI) de l'École Supérieure Polytechnique (ESP/UCAD), Dakar. Utilise ce skill dès que l'utilisateur demande à créer, formater, corriger ou générer un rapport de TP, rapport de stage, rapport de projet, mémoire de fin d'études, cahier des charges (CDC), ou tout autre document académique DGI/ESP. Déclencher aussi si l'utilisateur mentionne un fichier Word (.docx) à remettre pour un cours à l'ESP, demande une mise en conformité, une "mise en forme DGI", une page de garde ESP/UCAD, ou cite des normes DGI. Ce skill remplace toute autre consigne de formatage.
---

# DGI Academic Formatter

Ce skill transforme tout contenu brut en document académique conforme aux normes officielles du Département Génie Informatique (DGI), ESP/UCAD, Dakar. Il s'applique aux rapports de TP, rapports de stage, rapports de projet et mémoires de fin d'études.

---

## 1. Typographie & Mise en page

| Paramètre              | Valeur                              |
|------------------------|-------------------------------------|
| Police                 | Times New Roman, 12 pt              |
| Interligne             | 1,5 (interligne et demi)            |
| Alignement             | Justifié (tout le document)         |
| Marges Haut/Bas/Gauche | 2,5 cm                              |
| Marge Droite           | 1,5 cm (marge de reliure)           |
| Couleurs               | Noir uniquement (sauf schémas)      |

---

## 2. Pagination

- **Pages liminaires** (Dédicace → Acronymes) : chiffres romains minuscules *(i, ii, iii…)*
- **Corps du document** (Introduction → Conclusion) : chiffres arabes *(1, 2, 3…)*, recommençant à 1
- **Annexes** : suite de la numérotation arabe ou lettrage *(A-1, A-2…)*
- **Position** : bas de page, aligné à droite

---

## 3. Niveaux de titres

| Niveau | Exemple                                 | Style                                 |
|--------|-----------------------------------------|---------------------------------------|
| H1     | `CHAPITRE I : TITRE EN MAJUSCULES`      | 14 pt, gras, centré, nouvelle page    |
| H2     | `1.1 Titre de section`                  | 13 pt, gras, aligné gauche            |
| H3     | `1.1.1 Titre de sous-section`           | 12 pt, gras, aligné gauche            |
| H4     | `1.1.1.1 Titre de paragraphe`           | 12 pt, gras italique, aligné gauche   |

- La numérotation est **automatique et hiérarchique** (1, 1.1, 1.1.1…).
- Chaque chapitre commence sur une **nouvelle page**.
- Pas de titre de niveau > H4.

---

## 4. Structure complète du document

Suivre cet ordre séquentiel exact. Les éléments entre parenthèses sont facultatifs selon le type de document.

### Pages liminaires *(numérotées en romain)*

1. **Page de garde** *(voir section 5)*
2. **Dédicace** *(facultatif)*
3. **Remerciements**
4. **Résumé** (français, ~200 mots) + **Abstract** (anglais, ~200 mots)
5. **Table des matières** — avec numéros de page
6. **Liste des figures** *(si ≥ 3 figures)*
7. **Liste des tableaux** *(si ≥ 3 tableaux)*
8. **Liste des abréviations et acronymes** *(si applicable)*

### Corps du document *(numéroté en arabe)*

9. **Introduction générale** — contexte, problématique, objectifs, plan du document
10. **Chapitres de développement** — dépendent de l'énoncé
11. **Conclusion générale** — bilan, limites, perspectives

### Parties finales *(suite de la numérotation)*

12. **Bibliographie / Webographie** *(voir section 7)*
13. **Annexes** *(si applicable, chaque annexe lettrée : Annexe A, B…)*

---

## 5. Page de garde

Modèle **obligatoire** inspiré des pages de garde officielles ESP/UCAD. Reproduire fidèlement cette structure, de haut en bas :

```
[Logo Sénégal — gauche]    République du Sénégal        [Drapeau Sénégal — droite]
                           Un Peuple – Un But – Une Foi

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ministère de l'Enseignement Supérieur de la Recherche et de l'Innovation
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

              UNIVERSITE CHEIKH ANTA DIOP DE DAKAR

                      [Logo UCAD — centré]

                  ECOLE SUPERIEURE POLYTECHNIQUE
                  DEPARTEMENT GENIE INFORMATIQUE
                          Classe : DIC1

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

              [TITRE DU DOCUMENT]   ← en couleur (rouge/bleu selon thème)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

        [Technologie / Outil utilisé — texte gras centré]
                   [Logo de l'outil si disponible]

                        Réalisé par :
                       Prénom NOM

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

                  Année académique : 20XX – 20XX
```

### Règles de mise en forme de la page de garde

- **Bloc supérieur** : logo officiel Sénégal à gauche, drapeau à droite, texte "République du Sénégal / Un Peuple – Un But – Une Foi" centré entre les deux — **reproduire exactement cette disposition**
- **Logo UCAD** : centré seul sur sa ligne (pas de second logo à droite)
- **ESP / DGI / Classe** : centré, Times New Roman, normal (pas gras), taille 12–13 pt
- **Titre du TP/document** : Times New Roman 20–22 pt, **gras**, centré, en couleur (bleu `#1F3864` ou rouge `#C0392B` selon le contexte) — **pas en noir, pas en majuscules automatiques**
- **Outil/technologie** (ex. "Cisco Packet Tracer") : affiché en gras sous le titre si l'énoncé le mentionne, avec son logo si disponible
- **Réalisé par** : "Réalisé par :" en gras, nom en normal, les deux centrés
- **Filets horizontaux** : Word borders (pas de traits ASCII) au-dessus et en-dessous du titre
- **Pas de numéro de page** sur la page de garde (comptée mais non affichée)
- **Images** : insérer dans l'ordre exact spécifié — logo Sénégal → drapeau → logo UCAD → logo outil — ne jamais permuter ni dupliquer

---

## 6. Figures, tableaux & équations

### Figures
- Légende **sous** la figure, centrée
- Format : `Figure X.Y — Description courte.`  *(X = chapitre, Y = numéro dans le chapitre)*
- Exemple : `Figure 2.3 — Architecture du système proposé.`

### Tableaux
- Légende **au-dessus** du tableau, alignée à gauche
- Format : `Tableau X.Y — Description courte.`
- Exemple : `Tableau 1.1 — Comparaison des solutions existantes.`

**Style des tableaux en .docx :**

| Élément          | Style                                                                 |
|------------------|-----------------------------------------------------------------------|
| Ligne d'en-tête  | Fond **bleu ciel** `#BDD7EE`, texte noir, gras, centré               |
| Lignes impaires  | Fond **blanc** `#FFFFFF`                                              |
| Lignes paires    | Fond **gris très clair** `#F2F2F2`                                   |
| Bordures         | Grille fine, couleur `#000000` (noir)                                 |
| Police           | Times New Roman 11 pt dans les cellules                               |

- **Ne jamais utiliser un fond bleu foncé** pour les en-têtes de tableau
- Appliquer ce style à **tous** les tableaux du document, sans exception

### Équations
- Centrées, numérotées à droite entre parenthèses : `(X.Y)`
- Exemple : `(2.1)`

---

## 7. Bibliographie

Utiliser le style **IEEE** :

```
[1]  Initiale(s). Nom, Titre de l'ouvrage, Édition. Ville : Éditeur, Année.
[2]  A. Auteur et B. Coauteur, "Titre de l'article," Revue, vol. X, no. Y, pp. Z–Z, Année.
[3]  P. Nom, "Titre de la page." [En ligne]. Disponible : https://url.com. [Consulté le : JJ Mois AAAA].
```

- Références classées par **ordre d'apparition** dans le texte
- Appel de citation dans le texte : `[1]`, `[2, 3]`
- Section Webographie séparée si sources web > 5

---

## 8. Style rédactionnel

| Règle            | Application                                                      |
|------------------|------------------------------------------------------------------|
| Personne         | **Pas de "Je"** — utiliser "Nous" (modestie) ou voix passive     |
| Temps            | Présent de l'indicatif                                           |
| Ton              | Impersonnel, technique, précis                                   |
| Abréviations     | Définir à la première occurrence : `Réseau Local (LAN)`          |
| Anglicismes      | Éviter si équivalent français existant                           |
| Nombres          | Chiffres si > 9, lettres si ≤ 9                                  |
| Unités           | Système International (SI) uniquement                            |

---

## 9. Instructions d'activation

1. **L'utilisateur précise le type de document** : TP / Stage / Projet / Mémoire.
   → Adapter la structure selon le tableau de la section 10.

2. **Appliquer immédiatement** Times New Roman 12 pt, interligne 1,5, justifié à toutes les sections produites.

3. **Reformuler automatiquement** tout texte à la première personne ou dans un style informel.

4. **Corriger la hiérarchie** des titres si le contenu soumis ne respecte pas H1/H2/H3/H4.

5. **Générer les éléments manquants** si le contenu est partiel (résumé, remerciements, page de garde, etc.).

6. **Numérotation pour les Rapports de TP** :
   - **Respecter strictement la numérotation de l'énoncé** (ex. si l'énoncé dit "Partie II – Question 3", conserver cette numérotation telle quelle).
   - Ne pas renuméroter automatiquement les questions/exercices d'un TP.
   - Adapter uniquement les titres de chapitres/sections structurels (Introduction, Conclusion) selon la hiérarchie H1/H2, sans toucher à la numérotation interne des questions.

7. **Ordre des images** :
   - Insérer les images dans l'**ordre exact** fourni par l'utilisateur ou dicté par l'énoncé.
   - Ne jamais permuter, dupliquer ou remplacer une image par une autre.
   - En cas de doute sur l'ordre, demander confirmation avant d'insérer.
   - Sur la page de garde : respecter l'ordre logo Sénégal → drapeau → logo UCAD → logo outil (si applicable).

---

## 10. Variantes par type de document

| Type              | Dédicace   | Résumé/Abstract | Liste fig/tab  | Annexes      |
|-------------------|------------|-----------------|----------------|--------------|
| Rapport de TP     | ✗          | ✗               | Si ≥ 3         | Selon besoin |
| Rapport de Stage  | Optionnel  | ✓               | Si ≥ 3         | ✓            |
| Rapport de Projet | Optionnel  | ✓               | Si ≥ 3         | ✓            |
| Mémoire FE        | ✓          | ✓ (obligatoire) | ✓ (obligatoire)| ✓            |
